<nav class="navbar navbar-light bg-light">
    <a class="col-md-6" href="../view/LoginPessoaVIEW.php"> <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Gnome-home.svg/1200px-Gnome-home.svg.png" class="h-auto d-inline-block align-top float-left rounded-circle" alt="" width="25px">
    </a>
</nav>
