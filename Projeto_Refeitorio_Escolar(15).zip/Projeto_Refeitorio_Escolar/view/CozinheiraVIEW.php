<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php include_once '../dao/PessoaDAO.php';
?>
<html>
    <head>
        <title>Refeitório Escolar</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="../css/style.css" rel="stylesheet" type="text/css"/>
        <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="../css/style_1.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="../bootstrap/css/bootstrap-theme.css" type="text/css">
        <link rel="stylesheet" href="../bootstrap/css/bootstrap-theme.css" type="text/css"/>
    </head>
    <body background= "../img/refeicao.jpg"  >
         <nav class="site-header">
                      <div class="container">
                <div class="row">
                    <a class="col-md-3" href="LoginPessoaVIEW.php"> <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d7/Gnome-home.svg/1200px-Gnome-home.svg.png" class="h-auto d-inline-block align-top float-left rounded-circle" alt="" width="25px">
                    </a>
                    <a class="col-md-4" href="CadastroCardapioDiarioVIEW.php">Cadastrar Cardápio Diário</a>
                    <a class="col-md-4" href="CadastroCardapioSemanalVIEW.php">Cadastrar Cardápio Semanal</a>
<!--                    <a class="col-md-3" href="RespostaConfirmacaoVIEW.php">Visualizar Dados</a>-->
                    
                </div>
            </div>
                  </nav>
      
    </body>
</html>

